

### Installations
* npm install

### Run

* npm run start

:)

name
created_date,
status

localhost:3000/tasks     (will call get)