#!/bin/sh
echo "running this shell script from child_process.execFile"
# run another node process
node execdemo.js server.js

