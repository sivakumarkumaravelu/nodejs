#include "stdafx.h"
#pragma comment(lib, "node")
#include <node.h>
#include <v8.h>
#include <Windows.h>

using namespace v8;

Handle<Value> sayHi(const Arguments& args) {
    HandleScope scope;
    MessageBoxW(NULL, TEXT("You have been greeted!"), TEXT("Attention!"), MB_OK);
    return scope.Close(String::New("Bye, bye! Come again!"));
}

extern "C" void NODE_EXTERN init (Handle<Object> target) {
    HandleScope scope;
    target->Set(String::NewSymbol("sayHi"), FunctionTemplate::New(sayHi)->GetFunction());
}