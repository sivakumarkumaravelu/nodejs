var addon = require('./build/Release/myAddon.node');
console.log(addon.sayHello());

//> node index.js